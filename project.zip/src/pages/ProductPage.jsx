import React, {useContext, useEffect, useState} from 'react';
import {Col, Container, Image, Row, Card, Button} from "react-bootstrap";
import {useParams} from 'react-router-dom'
import {fetchOneProduct} from "../http/productAPI";
import {LOGIN_ROUTE} from "../utils/consts";
import {Context} from "../index";

const ProductPage = () => {
    const [product, setProduct] = useState({info: []})
    const {id} = useParams()
    const {user} = useContext(Context)
    useEffect(() => {
        fetchOneProduct(id).then(data => setProduct(data))
    }, [])
        return (
        <Container className="mt-3">
            <Row>
            <Col md={4}>
                <Image width={300} height={300} src={process.env.REACT_APP_API_URL + product.img}/>
            </Col>
            <Col md={4}>
                <Row>
                    <h2>{product.name}</h2>
                </Row>
            </Col>
            <Col md={4}>
                <Card
                    className="d-flex flex-column align-items-center justify-content-around"
                    style={{width: 300, height: 300, fontSize: 32, border: '5px solid lightgray'}}
                >
                    <h3>От: {product.price} руб.</h3>
                    {user.isAuth ? <Button variant={"outline-dark"}>В корзину!</Button> : <div className="text-sm-center">Чтобы добавить в корзину, <a href={LOGIN_ROUTE}>авторизируйтесь</a></div>}
                </Card>
            </Col>
            </Row>
            <Row className="d-flex flex-column m-5">
                <h1>Характеристики</h1>
                {product.info.map((info, index) =>
                    <Row key={info.id} style={{background: index % 2 === 0 ? 'lightgray' : 'transparent', padding: 10}}>
                        {info.title}: {info.description}
                    </Row>
                )}
            </Row>
        </Container>
    );
};

export default ProductPage;