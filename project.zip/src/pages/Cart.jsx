import React from 'react';

const Cart = () => {
    return (
        <div>
            CART
        </div>
    );
};

export default Cart;